<?php
// Envio telegram
// true = SI | false = NO
$telegram_send = true;
$bottoken = "6981498151:AAGpbbK_PquKAzHY5-r7KpukaNiNzDHPFrs";
$chatid = "6020241392";
?>